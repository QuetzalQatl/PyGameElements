from PyGameElements.pygameElements import Label, InputBox, Square, Ellipse, Image, Line, CheckBox, Button
from PyGameElements.testPygameElements import testPygameElements