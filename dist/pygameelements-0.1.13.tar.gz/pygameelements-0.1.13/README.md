# PyGameElements so you dont have to make a gui for pygame every time you write a game

PyGameElements provides you with a way to use elements that scale along with the screen size. 

# Overview
To be done

  - Bla
  - Bla
  - Bla


## Usage

In the following paragraphs, I am going to describe how you can get and use PyGameElements for your own projects.

###  Getting it

To download PyGameElements, either fork this github repo or simply use Pypi via pip.
```sh
$ pip install PyGameElements
```

### Using it

PyGameElements was programmed with ease-of-use in mind. First, import simpleText from PyGameElements

```Python
from PyGameElements import simpleText
```

And you are ready to go! 

Done.





License
----

MIT License

Copyright (c) 2020 Bas Koning

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.


Hire us: basknng@gmail.com

