from pygameElements.pygameElements import Label, InputBox, Square, Ellipse, Image, Line, CheckBox, Button

from pygameElementsTest.testPygameElements import testPygameElements